from django.apps import AppConfig


class CsvHandlerConfig(AppConfig):
    name = 'csv_handler'
